import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { getToken } from 'next-auth/jwt';
import { isEmailAllowed } from '@/types';

const ACCESS_DENIED_URL = '/access-denied';

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Allow NextAuth routes — required for the OAuth flow to work
  if (pathname.startsWith('/api/auth')) {
    return NextResponse.next();
  }

  // Allow Next.js internals
  if (pathname.startsWith('/_next/static') || pathname === '/favicon.ico') {
    return NextResponse.next();
  }

  // Block direct access to /assets/photos/* (served through public/)
  if (pathname.startsWith('/assets/photos')) {
    const token = await getToken({ req: request, secret: process.env.AUTH_SECRET });
    if (!token?.email || !isEmailAllowed(token.email)) {
      return NextResponse.redirect(new URL(ACCESS_DENIED_URL, request.url));
    }
  }

  // For /access-denied — let it render the 403 page
  if (pathname === '/access-denied') {
    return NextResponse.next();
  }

  // For all other routes, verify auth
  const token = await getToken({ req: request, secret: process.env.AUTH_SECRET });
  const isAuthenticated = !!token?.email;
  const isAllowed = isAuthenticated && isEmailAllowed(token.email);

  if (!isAuthenticated || !isAllowed) {
    // Allow root to render (it shows the login gate or access denied client-side)
    if (pathname === '/') {
      const response = NextResponse.next();
      response.headers.set('x-auth-status', 'unauthenticated');
      return response;
    }
    return NextResponse.redirect(new URL(ACCESS_DENIED_URL, request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/((?!_next/image|_next/static|api/auth|favicon.ico).*)',
  ],
};