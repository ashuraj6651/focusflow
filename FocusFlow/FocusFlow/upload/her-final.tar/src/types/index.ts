const ALLOWED_EMAILS: readonly string[] = Object.freeze([
  'priyamonijnvkh2005@gmail.com',
  'ashuraj6651@gmail.com',
]);

const NORMALIZED_ALLOWED = ALLOWED_EMAILS.map((e) => e.toLowerCase().trim());

export function isEmailAllowed(email: unknown): boolean {
  if (typeof email !== 'string') return false;
  return NORMALIZED_ALLOWED.includes(email.toLowerCase().trim());
}

export interface Photo {
  id: string;
  src: string;
  alt: string;
  caption?: string;
}