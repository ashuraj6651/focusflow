import { NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';
import { isEmailAllowed } from '@/types';
import { readFile } from 'fs/promises';
import { join, extname } from 'path';
import { createHash } from 'crypto';

const IMAGE_EXTENSIONS = new Set(['.jpg', '.jpeg', '.png', '.webp', '.avif', '.gif']);
const MIME_TYPES: Record<string, string> = {
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.avif': 'image/avif',
  '.gif': 'image/gif',
};

export async function GET(request: Request) {
  // Verify auth first
  try {
    const token = await getToken({ req: request as unknown as Parameters<typeof getToken>[0], secret: process.env.AUTH_SECRET });
    if (!token?.email || !isEmailAllowed(token.email)) {
      return new NextResponse('Unauthorized', { status: 401 });
    }
  } catch {
    return new NextResponse('Unauthorized', { status: 401 });
  }

  try {
    const { searchParams } = new URL(request.url);
    const file = searchParams.get('file');

    if (!file) {
      return new NextResponse('Missing file parameter', { status: 400 });
    }

    // Path traversal prevention
    const safeName = file.replace(/[/\\]/g, '').replace(/\.\./g, '');
    if (!safeName || safeName !== file) {
      return new NextResponse('Invalid file', { status: 400 });
    }

    const ext = extname(safeName).toLowerCase();
    if (!IMAGE_EXTENSIONS.has(ext)) {
      return new NextResponse('Unsupported type', { status: 400 });
    }

    const filePath = join(process.cwd(), 'private-photos', safeName);
    const buffer = await readFile(filePath);
    const mimeType = MIME_TYPES[ext] || 'application/octet-stream';
    const etag = createHash('md5').update(buffer).digest('hex').slice(0, 16);

    return new NextResponse(buffer, {
      status: 200,
      headers: {
        'Content-Type': mimeType,
        'Cache-Control': 'private, max-age=86400, immutable',
        'ETag': `"${etag}"`,
        'X-Content-Type-Options': 'nosniff',
      },
    });
  } catch {
    return new NextResponse('Not found', { status: 404 });
  }
}