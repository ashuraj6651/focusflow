import { NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';
import { isEmailAllowed } from '@/types';
import { readdir } from 'fs/promises';
import { join, extname } from 'path';

const IMAGE_EXTENSIONS = new Set(['.jpg', '.jpeg', '.png', '.webp', '.avif', '.gif']);

export async function GET(request: Request) {
  // Always verify auth, never return data without it
  try {
    const token = await getToken({ req: request as unknown as Parameters<typeof getToken>[0], secret: process.env.AUTH_SECRET });
    if (!token?.email || !isEmailAllowed(token.email)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
  } catch {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const photosDir = join(process.cwd(), 'private-photos');
    const files = await readdir(photosDir);

    const photos = files
      .filter((file) => {
        const ext = extname(file).toLowerCase();
        return IMAGE_EXTENSIONS.has(ext);
      })
      .map((file, index) => ({
        id: `photo-${index}`,
        src: `/api/images?file=${encodeURIComponent(file)}`,
        alt: file.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '),
      }));

    return NextResponse.json(photos);
  } catch {
    return NextResponse.json([]);
  }
}