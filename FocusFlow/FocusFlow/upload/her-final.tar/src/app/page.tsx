'use client';

import { useState, useEffect, useCallback, lazy, Suspense } from 'react';
import { SessionProvider, useSession } from 'next-auth/react';
import { isEmailAllowed } from '@/types';

import StarField from '@/components/effects/StarField';
import FloatingParticles from '@/components/effects/FloatingParticles';
import MouseGlow from '@/components/effects/MouseGlow';
import CursorTrail from '@/components/effects/CursorTrail';
import MusicPlayer from '@/components/effects/MusicPlayer';
import SecretLetter from '@/components/effects/SecretLetter';

import AuthGate from '@/components/auth/AuthGate';
import AccessDenied from '@/components/auth/AccessDenied';

const LandingSection = lazy(() => import('@/components/landing/LandingSection'));
const GallerySection = lazy(() => import('@/components/gallery/GallerySection'));
const ScrapbookSection = lazy(() => import('@/components/scrapbook/ScrapbookSection'));
const EndingSection = lazy(() => import('@/components/ending/EndingSection'));

function useLenisScroll() {
  useEffect(() => {
    let lenis: import('lenis').default | null = null;
    let rafId: number;

    async function init() {
      const Lenis = (await import('lenis')).default;
      lenis = new Lenis({
        duration: 1.2,
        easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        orientation: 'vertical' as const,
        gestureOrientation: 'vertical' as const,
        smoothWheel: true,
      });

      function animate(time: number) {
        lenis?.raf(time);
        rafId = requestAnimationFrame(animate);
      }
      rafId = requestAnimationFrame(animate);
    }

    init();

    return () => {
      cancelAnimationFrame(rafId);
      lenis?.destroy();
    };
  }, []);
}

function AppContent() {
  const { data: session, status } = useSession();
  const [phase, setPhase] = useState<'landing' | 'experience'>('landing');
  const [secretOpen, setSecretOpen] = useState(false);

  useLenisScroll();

  const email = session?.user?.email ?? '';
  const isAllowed = isEmailAllowed(email);

  const handleBegin = useCallback(() => {
    setPhase('experience');
    setTimeout(() => {
      document.getElementById('section-beginning')?.scrollIntoView({ behavior: 'smooth' });
    }, 200);
  }, []);

  const handleSecretLetter = useCallback(() => {
    setSecretOpen(true);
  }, []);

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#09090B]">
        <div className="w-8 h-8 border border-[#D4AF37]/20 border-t-[#D4AF37] rounded-full animate-spin" />
      </div>
    );
  }

  if (status === 'unauthenticated') {
    return <AuthGate />;
  }

  if (status === 'authenticated' && !isAllowed) {
    return <AccessDenied />;
  }

  return (
    <main className="relative">
      <div className="noise-texture" aria-hidden="true" />
      <StarField />
      <FloatingParticles />
      <MouseGlow />
      <CursorTrail />
      <MusicPlayer />
      <SecretLetter isOpen={secretOpen} onClose={() => setSecretOpen(false)} />

      {phase === 'landing' && (
        <LandingSection onBegin={handleBegin} onSecretLetter={handleSecretLetter} />
      )}

      {phase === 'experience' && (
        <div className="relative z-10">
          <div id="section-beginning">
            <GallerySection />
          </div>

          <div className="max-w-xs mx-auto">
            <div className="h-px bg-gradient-to-r from-transparent via-[#D4AF37]/15 to-transparent" />
          </div>

          <ScrapbookSection />

          <div className="max-w-xs mx-auto">
            <div className="h-px bg-gradient-to-r from-transparent via-[#D4AF37]/15 to-transparent" />
          </div>

          <EndingSection isActive />
        </div>
      )}
    </main>
  );
}

function SessionProviderWrapper() {
  return (
    <SessionProvider session={undefined}>
      <AppContent />
    </SessionProvider>
  );
}

export default function Home() {
  return <SessionProviderWrapper />;
}