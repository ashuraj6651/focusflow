'use client';

import { motion } from 'framer-motion';

interface TimelineEvent {
  date: string;
  title: string;
  description: string;
}

interface TimelineProps {
  events: TimelineEvent[];
}

export default function Timeline({ events }: TimelineProps) {
  return (
    <div className="relative max-w-2xl mx-auto">
      {/* Center line */}
      <motion.div
        initial={{ scaleY: 0 }}
        whileInView={{ scaleY: 1 }}
        viewport={{ once: true, margin: '-100px' }}
        transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-[#D4AF37]/20 to-transparent origin-top"
      />

      {events.map((event, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: i % 2 === 0 ? -30 : 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{
            duration: 0.6,
            delay: i * 0.15,
            ease: [0.16, 1, 0.3, 1],
          }}
          className={`relative flex items-start gap-6 md:gap-12 mb-12 last:mb-0 ${
            i % 2 === 0 ? 'md:flex-row-reverse md:text-right' : ''
          }`}
        >
          {/* Dot on timeline */}
          <div className="absolute left-4 md:left-1/2 w-2 h-2 -translate-x-1/2 mt-6">
            <div className="w-2 h-2 rounded-full bg-[#D4AF37]/40" />
            <div className="absolute inset-0 w-2 h-2 rounded-full bg-[#D4AF37]/20 animate-ping" style={{ animationDuration: '3s' }} />
          </div>

          {/* Content */}
          <div className={`ml-10 md:ml-0 md:w-[calc(50%-2rem)] ${i % 2 === 0 ? 'md:pr-8' : 'md:pl-8'}`}>
            <span className="text-[10px] tracking-[0.3em] uppercase text-[#D4AF37]/40 mb-2 block">
              {event.date}
            </span>
            <h4 className="text-base md:text-lg font-light text-white/80 mb-2">
              {event.title}
            </h4>
            <p className="text-sm text-white/35 leading-relaxed font-light">
              {event.description}
            </p>
          </div>

          {/* Spacer for opposite side */}
          <div className="hidden md:block md:w-[calc(50%-2rem)]" />
        </motion.div>
      ))}
    </div>
  );
}