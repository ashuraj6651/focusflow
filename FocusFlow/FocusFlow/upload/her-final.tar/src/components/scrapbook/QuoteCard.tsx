'use client';

import { motion } from 'framer-motion';

interface QuoteCardProps {
  text: string;
  author?: string;
  index: number;
}

export default function QuoteCard({ text, author, index }: QuoteCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-30px' }}
      transition={{
        duration: 0.8,
        delay: index * 0.15,
        ease: [0.16, 1, 0.3, 1],
      }}
      className="relative py-8 px-6"
    >
      <div className="glass rounded-2xl p-8 md:p-12 relative overflow-hidden">
        {/* Large quote mark */}
        <div className="absolute top-2 left-4 md:left-6 text-6xl md:text-8xl text-[#D4AF37]/5 font-serif leading-none select-none">
          &ldquo;
        </div>

        {/* Quote text */}
        <blockquote className="relative z-10">
          <p className="handwritten text-base md:text-lg text-white/60 leading-relaxed italic">
            {text}
          </p>
        </blockquote>

        {/* Author */}
        {author && (
          <div className="relative z-10 mt-6 flex items-center gap-3">
            <div className="w-6 h-px bg-[#D4AF37]/30" />
            <cite className="text-[11px] tracking-[0.2em] uppercase text-[#D4AF37]/40 not-italic">
              {author}
            </cite>
          </div>
        )}
      </div>
    </motion.div>
  );
}