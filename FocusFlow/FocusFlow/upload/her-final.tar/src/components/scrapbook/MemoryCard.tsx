'use client';

import { motion } from 'framer-motion';

interface MemoryCardProps {
  title: string;
  description: string;
  date: string;
  index: number;
}

export default function MemoryCard({ title, description, date, index }: MemoryCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.95 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: '-30px' }}
      transition={{
        duration: 0.7,
        delay: index * 0.1,
        ease: [0.16, 1, 0.3, 1],
      }}
      className="glass rounded-2xl p-6 md:p-8 group hover:glass-strong transition-all duration-500 cursor-default"
    >
      {/* Date badge */}
      <div className="flex items-center gap-3 mb-4">
        <div className="w-8 h-px bg-[#D4AF37]/30" />
        <span className="text-[11px] tracking-[0.2em] uppercase text-[#D4AF37]/50">
          {date}
        </span>
      </div>

      {/* Title */}
      <h3 className="text-lg md:text-xl font-light text-white/90 mb-3 group-hover:text-[#D4AF37] transition-colors duration-500">
        {title}
      </h3>

      {/* Description */}
      <p className="text-sm text-white/40 leading-relaxed font-light">
        {description}
      </p>

      {/* Bottom accent */}
      <div className="mt-6 h-px bg-gradient-to-r from-[#D4AF37]/20 via-transparent to-transparent" />
    </motion.div>
  );
}