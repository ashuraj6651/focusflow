'use client';

import { motion } from 'framer-motion';

interface TinyNoteProps {
  text: string;
  rotation: number;
  color: string;
  index: number;
}

export default function TinyNote({ text, rotation, color, index }: TinyNoteProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8, rotate: 0 }}
      whileInView={{ opacity: 1, scale: 1, rotate: rotation }}
      viewport={{ once: true, margin: '-20px' }}
      transition={{
        duration: 0.6,
        delay: index * 0.08,
        ease: [0.16, 1, 0.3, 1],
      }}
      className="inline-block"
    >
      <div
        className="glass rounded-lg px-4 py-3 max-w-[220px] hover:scale-105 transition-transform duration-300"
        style={{
          borderLeft: `2px solid ${color}`,
        }}
      >
        <p className="text-xs text-white/40 leading-relaxed handwritten">
          {text}
        </p>
      </div>
    </motion.div>
  );
}