'use client';

import { motion } from 'framer-motion';
import MemoryCard from './MemoryCard';
import Timeline from './Timeline';
import QuoteCard from './QuoteCard';
import TinyNote from './TinyNote';

const littleMoments = [
  {
    title: 'The First Hello',
    description: 'A conversation that was supposed to last five minutes. It didn\'t. Some moments don\'t announce themselves — they just arrive and quietly rearrange everything.',
    date: 'The Beginning',
  },
  {
    title: '2 AM Calls',
    description: 'The world was asleep. We weren\'t. Words come easier in the dark, when there\'s nothing left to hide behind. Every "one more minute" was a small confession.',
    date: 'The Beginning',
  },
  {
    title: 'The Song',
    description: 'You sent a song once. Just a link, no explanation. I pressed play and something shifted — like recognizing a place you\'ve never been.',
    date: 'The Beginning',
  },
  {
    title: 'Found You',
    description: 'Not by looking. By being found. Two orbits that should have never crossed, except they did. And the gravity was immediate.',
    date: 'The Beginning',
  },
];

const favoriteMemories = [
  {
    title: 'Late Nights',
    description: 'Time zones, schedules, obligations — none of it mattered. What mattered was the voice on the other end, and the feeling that this was exactly where I was supposed to be.',
    date: 'Favorite Memory',
  },
  {
    title: 'The Little Things',
    description: 'A remembered detail. A perfectly timed message. A laugh shared over something nobody else would understand. Proof that someone was paying attention to the things that matter most.',
    date: 'Favorite Memory',
  },
  {
    title: 'Silence',
    description: 'Not the awkward kind. The comfortable kind. The kind where you don\'t need to fill the space because just being there is enough. That silence said more than a thousand conversations.',
    date: 'Favorite Memory',
  },
  {
    title: 'Finding Home',
    description: 'Home stopped being a place. It became a voice, a presence, a person at the end of a long day who made everything feel like it was going to be okay.',
    date: 'Favorite Memory',
  },
];

const timelineEvents = [
  {
    date: 'Once',
    title: 'A Conversation Started',
    description: 'Two strangers. One conversation. Nothing special about it on paper. Except paper never captures the feeling of knowing, in that exact moment, that something is different.',
  },
  {
    date: 'Then',
    title: 'Nights Became Ours',
    description: 'When the world went quiet, we came alive. Conversations stretched until dawn. Sleep became optional. What we shared in those hours became the foundation of something neither of us expected.',
  },
  {
    date: 'Slowly',
    title: 'Words Became Unnecessary',
    description: 'A look across a screen. A pause before speaking. A message that arrived at exactly the right moment. We learned to communicate in frequencies most people never discover.',
  },
  {
    date: 'Now',
    title: 'Two Worlds, One Orbit',
    description: 'Different lives. Different paths. Different everything — except for the invisible thread that keeps pulling us back to each other, again and again.',
  },
];

const unsaidThings = [
  {
    text: 'I found you not by looking, but by being found. You walked into my ordinary and made it extraordinary without even trying.',
  },
  {
    text: 'Of all the roads in all the world, ours happened to cross. And I think the universe knew exactly what it was doing.',
    author: 'a quiet thought',
  },
  {
    text: 'Some people feel like home. Not the walls-and-roof kind, but the kind that lives in your chest and beats alongside your heart.',
  },
];

const tinyNotes = [
  { text: 'that rainy evening, remember?', rotation: -1.8, color: 'rgba(212, 175, 55, 0.25)' },
  { text: 'you laughed and i forgot to breathe', rotation: 1.2, color: 'rgba(168, 130, 74, 0.25)' },
  { text: '3am thoughts that only make sense to us', rotation: -0.8, color: 'rgba(232, 212, 139, 0.2)' },
  { text: 'the song you sent — still on repeat', rotation: 1.5, color: 'rgba(212, 175, 55, 0.15)' },
  { text: 'some things don\'t need explaining', rotation: -1.2, color: 'rgba(184, 150, 12, 0.25)' },
  { text: 'your voice is my favorite frequency', rotation: 0.8, color: 'rgba(232, 212, 139, 0.15)' },
  { text: 'i didn\'t know what home felt like until now', rotation: -1.5, color: 'rgba(212, 175, 55, 0.2)' },
  { text: 'you make silence feel like a conversation', rotation: 1, color: 'rgba(168, 130, 74, 0.2)' },
];

const presentAndFuture = [
  {
    title: 'Right Now',
    description: 'This moment. This screen. This quiet understanding between us that doesn\'t need validation or explanation. Whatever this is, it\'s the realest thing I\'ve ever known.',
    date: 'The Present',
  },
  {
    title: 'What Comes Next',
    description: 'I don\'t know what the future holds. But I know who I want it with. And that knowledge, simple as it is, feels like the most certain thing in the world.',
    date: 'The Future',
  },
  {
    title: 'Always',
    description: 'Not forever — forever feels too small. Always. In every timeline, every version of this story, in every universe where we exist, I\'d choose this. I\'d choose you.',
    date: 'The Future',
  },
];

function SectionHeader({ label, title, description }: { label: string; title: string; description: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.8 }}
      className="text-center mb-16 md:mb-20"
    >
      <p className="text-[11px] tracking-[0.4em] uppercase text-[#D4AF37]/40 mb-4">
        {label}
      </p>
      <h2 className="text-2xl md:text-4xl font-extralight text-white/85 tracking-tight mb-4">
        {title}
      </h2>
      <motion.div
        initial={{ scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1, delay: 0.2 }}
        className="w-16 h-px bg-gradient-to-r from-transparent via-[#D4AF37]/30 to-transparent mx-auto mb-6"
      />
      <p className="text-sm text-white/20 max-w-md mx-auto font-light leading-relaxed">
        {description}
      </p>
    </motion.div>
  );
}

export default function ScrapbookSection() {
  return (
    <section className="relative py-24 md:py-32 px-6">
      {/* ─── ii. Little Moments ─── */}
      <SectionHeader
        label="ii."
        title='Little Moments'
        description="The small things that didn't seem like much then. But they were everything."
      />
      <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-5 mb-28 md:mb-36">
        {littleMoments.map((m, i) => (
          <MemoryCard key={i} title={m.title} description={m.description} date={m.date} index={i} />
        ))}
      </div>

      {/* ─── iii. Favorite Memories ─── */}
      <SectionHeader
        label="iii."
        title='Favorite Memories'
        description="Some memories replay on their own. These are the ones that do."
      />
      <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-5 mb-28 md:mb-36">
        {favoriteMemories.map((m, i) => (
          <MemoryCard key={i} title={m.title} description={m.description} date={m.date} index={i} />
        ))}
      </div>

      {/* ─── Tiny Notes interlude ─── */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.8 }}
        className="text-center mb-12"
      >
        <p className="text-[11px] tracking-[0.4em] uppercase text-[#D4AF37]/30 mb-3">
          between the lines
        </p>
      </motion.div>
      <div className="flex flex-wrap justify-center gap-3 md:gap-4 mb-28 md:mb-36">
        {tinyNotes.map((note, i) => (
          <TinyNote key={i} text={note.text} rotation={note.rotation} color={note.color} index={i} />
        ))}
      </div>

      {/* ─── iv. Things I Never Say Out Loud ─── */}
      <SectionHeader
        label="iv."
        title='Things I Never Say Out Loud'
        description="The words that stay buried. Until now."
      />
      <div className="max-w-3xl mx-auto mb-28 md:mb-36">
        {unsaidThings.map((q, i) => (
          <QuoteCard key={i} text={q.text} author={q.author} index={i} />
        ))}
      </div>

      {/* ─── v. How We Got Here (Timeline) ─── */}
      <SectionHeader
        label="v."
        title='How We Got Here'
        description="A map of the quiet journey that led us to now."
      />
      <div className="max-w-4xl mx-auto mb-28 md:mb-36 px-4">
        <Timeline events={timelineEvents} />
      </div>

      {/* ─── vi. The Present & The Future ─── */}
      <SectionHeader
        label="vi."
        title='The Present. The Future.'
        description="Where we are. Where we're going."
      />
      <div className="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
        {presentAndFuture.map((m, i) => (
          <MemoryCard key={i} title={m.title} description={m.description} date={m.date} index={i} />
        ))}
      </div>

      <div className="h-8" />
    </section>
  );
}