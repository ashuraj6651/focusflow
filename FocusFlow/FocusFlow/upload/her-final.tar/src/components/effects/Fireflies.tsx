'use client';

import { useEffect, useRef, useCallback } from 'react';

interface Firefly {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  opacity: number;
  pulseSpeed: number;
  pulsePhase: number;
}

export default function Fireflies({ count = 25 }: { count?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const firefliesRef = useRef<Firefly[]>([]);
  const frameRef = useRef<number>(0);

  const initFireflies = useCallback((width: number, height: number) => {
    firefliesRef.current = Array.from({ length: count }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.5,
      vy: (Math.random() - 0.5) * 0.3 - 0.1,
      size: Math.random() * 2 + 1,
      opacity: 0,
      pulseSpeed: Math.random() * 0.03 + 0.01,
      pulsePhase: Math.random() * Math.PI * 2,
    }));
  }, [count]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const container = canvas.parentElement;
      if (container) {
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
        initFireflies(canvas.width, canvas.height);
      }
    };
    resize();
    window.addEventListener('resize', resize, { passive: true });

    let time = 0;
    const animate = () => {
      time++;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      firefliesRef.current.forEach((f) => {
        f.x += f.vx + Math.sin(time * 0.01 + f.pulsePhase) * 0.2;
        f.y += f.vy + Math.cos(time * 0.008 + f.pulsePhase) * 0.15;

        if (f.x < -20) f.x = canvas.width + 20;
        if (f.x > canvas.width + 20) f.x = -20;
        if (f.y < -20) f.y = canvas.height + 20;
        if (f.y > canvas.height + 20) f.y = -20;

        const pulse = Math.sin(time * f.pulseSpeed + f.pulsePhase);
        const opacity = 0.3 + 0.7 * ((pulse + 1) / 2);
        const glowSize = f.size * (2 + pulse * 0.5);

        // Outer glow
        const gradient = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, glowSize * 6);
        gradient.addColorStop(0, `rgba(212, 175, 55, ${opacity * 0.15})`);
        gradient.addColorStop(1, 'transparent');
        ctx.beginPath();
        ctx.arc(f.x, f.y, glowSize * 6, 0, Math.PI * 2);
        ctx.fillStyle = gradient;
        ctx.fill();

        // Inner glow
        const innerGrad = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, glowSize);
        innerGrad.addColorStop(0, `rgba(255, 240, 180, ${opacity * 0.8})`);
        innerGrad.addColorStop(0.5, `rgba(212, 175, 55, ${opacity * 0.3})`);
        innerGrad.addColorStop(1, 'transparent');
        ctx.beginPath();
        ctx.arc(f.x, f.y, glowSize, 0, Math.PI * 2);
        ctx.fillStyle = innerGrad;
        ctx.fill();

        // Core
        ctx.beginPath();
        ctx.arc(f.x, f.y, f.size * 0.5, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 248, 220, ${opacity})`;
        ctx.fill();
      });

      frameRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(frameRef.current);
    };
  }, [initFireflies]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
      aria-hidden="true"
    />
  );
}