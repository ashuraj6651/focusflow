'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { Music, Volume2, VolumeX } from 'lucide-react';

export default function MusicPlayer() {
  const [isMuted, setIsMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isSpinning, setIsSpinning] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  const toggleMusic = useCallback(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio('/assets/music.mp3');
      audioRef.current.loop = true;
      audioRef.current.volume = 0.3;
    }

    if (isMuted) {
      audioRef.current.play().then(() => {
        setIsMuted(false);
        setIsPlaying(true);
        setIsSpinning(true);
      }).catch(() => {
        // Audio not available
      });
    } else {
      audioRef.current.pause();
      setIsMuted(true);
      setIsPlaying(false);
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(() => setIsSpinning(false), 2000);
    }
  }, [isMuted]);

  return (
    <button
      onClick={toggleMusic}
      className="fixed bottom-6 right-6 z-50 group"
      aria-label={isMuted ? 'Play music' : 'Pause music'}
    >
      <div className="relative w-14 h-14 flex items-center justify-center rounded-full glass transition-all duration-500 hover:scale-110 group-hover:gold-glow">
        {/* Vinyl disc */}
        <div
          className={`absolute inset-1.5 rounded-full bg-gradient-to-br from-zinc-800 to-zinc-900 border border-white/10 ${isSpinning ? 'animate-spin-slow' : 'animate-spin-slow paused'}`}
        >
          <div className="absolute inset-0 m-auto w-3 h-3 rounded-full bg-[#D4AF37]/30 border border-[#D4AF37]/20" />
          <div className="absolute inset-0 m-auto w-1.5 h-1.5 rounded-full bg-[#D4AF37]/50" />
        </div>

        {/* Icon overlay */}
        <div className="relative z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          {isMuted ? (
            <VolumeX className="w-5 h-5 text-[#FAFAFA]" />
          ) : (
            <Volume2 className="w-5 h-5 text-[#D4AF37]" />
          )}
        </div>

        {/* Status dot */}
        {isPlaying && (
          <div className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full bg-[#D4AF37] animate-pulse" />
        )}
      </div>
    </button>
  );
}