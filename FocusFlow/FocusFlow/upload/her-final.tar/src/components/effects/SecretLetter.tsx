'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

interface SecretLetterProps {
  isOpen: boolean;
  onClose: () => void;
}

const LETTER = `To the one who found this...

You always had a way of finding things
others couldn't see. Hidden meanings in songs,
secret paths in the woods, constellations
others missed in the night sky.

This was always meant for you, Monika.

Some letters aren't written to be sent.
They're written to exist — proof that someone,
somewhere, felt something so deeply
it needed a place to live outside their chest.

This is that place.

Every star on that landing page?
Each one is a moment I almost told you.
Every quiet second I chose words over silence,
then silence over words, then wondered
if the stars were trying to speak for me.

They were.
They still are.

You made the ordinary feel cinematic.
You made silence feel like music.
You made "goodnight" feel like a promise.

I don't say these things out loud.
But I built an entire universe just to say them.

— A`;

export default function SecretLetter({ isOpen, onClose }: SecretLetterProps) {
  const [displayText, setDisplayText] = useState('');

  useEffect(() => {
    if (!isOpen) {
      setDisplayText('');
      return;
    }

    let index = 0;
    const interval = setInterval(() => {
      if (index < LETTER.length) {
        setDisplayText(LETTER.slice(0, index + 1));
        index++;
      } else {
        clearInterval(interval);
      }
    }, 30);

    return () => clearInterval(interval);
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
        >
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            onClick={onClose}
          />

          {/* Letter */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0, y: 30 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-10 max-w-lg w-full max-h-[80vh] overflow-y-auto"
          >
            <div className="glass-strong rounded-2xl p-8 md:p-12 relative">
              <button
                onClick={onClose}
                className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center text-white/40 hover:text-white/80 hover:bg-white/5 transition-all duration-300"
                aria-label="Close letter"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Seal */}
              <div className="flex justify-center mb-8">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#D4AF37]/80 to-[#B8960C]/60 flex items-center justify-center gold-glow">
                  <span className="text-[#09090B]/80 font-serif font-bold text-lg italic">&amp;</span>
                </div>
              </div>

              {/* Letter content */}
              <div className="min-h-[280px]">
                <p className="handwritten text-white/70 text-sm md:text-base leading-relaxed whitespace-pre-wrap">
                  {displayText}
                  {displayText.length < LETTER.length && (
                    <span className="inline-block w-[2px] h-4 bg-[#D4AF37]/50 ml-0.5 animate-pulse" />
                  )}
                </p>
              </div>

              {/* Bottom */}
              <div className="mt-8 pt-5 border-t border-white/5 text-center">
                <p className="text-[9px] text-white/15 tracking-[0.3em] uppercase">
                  only for you
                </p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}