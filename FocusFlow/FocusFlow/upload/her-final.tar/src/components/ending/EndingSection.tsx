'use client';

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Fireflies from '@/components/effects/Fireflies';

interface EndingSectionProps {
  isActive: boolean;
}

export default function EndingSection({ isActive }: EndingSectionProps) {
  const [phase, setPhase] = useState<'idle' | 'line1' | 'line2' | 'line3' | 'line4' | 'hold' | 'fade'>('idle');
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isActive) return;

    const el = sectionRef.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && phase === 'idle') {
            setPhase('line1');
          }
        });
      },
      { threshold: 0.4 }
    );

    observer.observe(el);
    return () => observer.unobserve(el);
  }, [isActive, phase]);

  // Sequence the typing lines
  useEffect(() => {
    if (phase === 'line1') {
      const t = setTimeout(() => setPhase('line2'), 4000);
      return () => clearTimeout(t);
    }
    if (phase === 'line2') {
      const t = setTimeout(() => setPhase('line3'), 4500);
      return () => clearTimeout(t);
    }
    if (phase === 'line3') {
      const t = setTimeout(() => setPhase('line4'), 3500);
      return () => clearTimeout(t);
    }
    if (phase === 'line4') {
      const t = setTimeout(() => setPhase('hold'), 2000);
      return () => clearTimeout(t);
    }
    if (phase === 'hold') {
      const t = setTimeout(() => setPhase('fade'), 6000);
      return () => clearTimeout(t);
    }
  }, [phase]);

  if (phase === 'fade') {
    return (
      <section className="relative h-screen w-full flex items-center justify-center overflow-hidden bg-[#09090B]">
        <div className="absolute inset-0">
          <Fireflies count={30} />
        </div>
        <motion.div
          initial={{ opacity: 1 }}
          animate={{ opacity: 0 }}
          transition={{ duration: 5, ease: 'easeInOut' }}
          className="text-center relative z-10"
        />
      </section>
    );
  }

  const isActivePhase = phase !== 'idle';

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen w-full flex items-center justify-center overflow-hidden"
    >
      {/* Dark overlay */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={isActivePhase ? { opacity: 1 } : { opacity: 0 }}
        transition={{ duration: 3 }}
        className="absolute inset-0 bg-[#09090B] z-[1]"
      />

      {/* Fireflies */}
      <AnimatePresence>
        {isActivePhase && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 3 }}
            className="absolute inset-0 z-[2]"
          >
            <Fireflies count={50} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Content */}
      <div className="relative z-[10] text-center px-6 max-w-lg mx-auto">
        <AnimatePresence mode="wait">
          {isActivePhase && (
            <motion.div
              key="ending"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 2 }}
            >
              {/* Top line */}
              <motion.div
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 1.5, delay: 0.5 }}
                className="w-12 h-px bg-gradient-to-r from-transparent via-[#D4AF37]/20 to-transparent mx-auto mb-12 md:mb-16"
              />

              {/* Line 1: "Some people become memories. Some become home." */}
              {phase !== 'idle' && (
                <motion.p
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 1.2 }}
                  className="text-lg md:text-2xl text-white/50 font-extralight tracking-wide leading-relaxed mb-8"
                >
                  <Typewriter
                    text="Some people become memories."
                    active={phase === 'line1'}
                    speed={55}
                  />
                </motion.p>
              )}

              {/* Line 2: "Some become home." */}
              {(phase === 'line2' || phase === 'line3' || phase === 'line4' || phase === 'hold') && (
                <motion.p
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 1.2 }}
                  className="text-lg md:text-2xl text-white/50 font-extralight tracking-wide leading-relaxed mb-14"
                >
                  <Typewriter
                    text="Some become home."
                    active={phase === 'line2'}
                    speed={65}
                  />
                </motion.p>
              )}

              {/* Spacer */}
              {(phase === 'line3' || phase === 'line4' || phase === 'hold') && (
                <div className="h-12" />
              )}

              {/* Line 3: "Thank you, Monika." */}
              {(phase === 'line3' || phase === 'line4' || phase === 'hold') && (
                <motion.p
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 1.5 }}
                  className="text-2xl md:text-4xl text-[#D4AF37]/70 font-extralight tracking-tight mb-6"
                >
                  <Typewriter
                    text="Thank you, Monika."
                    active={phase === 'line3'}
                    speed={80}
                  />
                </motion.p>
              )}

              {/* Line 4: "— Ashu" */}
              {(phase === 'line4' || phase === 'hold') && (
                <motion.p
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 1.5, delay: 0.5 }}
                  className="text-sm text-white/20 tracking-[0.2em] uppercase font-light"
                >
                  — Ashu
                </motion.p>
              )}

              {/* Bottom line */}
              {phase === 'hold' && (
                <motion.div
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ duration: 2, delay: 1 }}
                  className="w-12 h-px bg-gradient-to-r from-transparent via-[#D4AF37]/20 to-transparent mx-auto mt-14"
                />
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}

// Minimal inline typewriter — avoids importing the landing component
function Typewriter({ text, active, speed }: { text: string; active: boolean; speed: number }) {
  const [displayed, setDisplayed] = useState('');

  useEffect(() => {
    if (!active) {
      setDisplayed('');
      return;
    }
    let i = 0;
    const interval = setInterval(() => {
      if (i < text.length) {
        setDisplayed(text.slice(0, i + 1));
        i++;
      } else {
        clearInterval(interval);
      }
    }, speed);
    return () => clearInterval(interval);
  }, [active, text, speed]);

  if (!active) return null;

  return (
    <>
      {displayed}
      {displayed.length < text.length && (
        <span className="inline-block w-[2px] h-[1em] bg-[#D4AF37]/60 ml-0.5 align-middle animate-pulse" />
      )}
    </>
  );
}