'use client';

import { motion } from 'framer-motion';

interface MoonProps {
  onDoubleClick: () => void;
}

export default function Moon({ onDoubleClick }: MoonProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 2, delay: 1, ease: [0.16, 1, 0.3, 1] }}
      className="absolute top-[12%] md:top-[15%] right-[10%] md:right-[15%]"
    >
      <div
        onDoubleClick={onDoubleClick}
        className="relative cursor-pointer group"
        role="button"
        tabIndex={0}
        aria-label="Double-click for a surprise"
        onKeyDown={(e) => {
          if (e.key === 'Enter') onDoubleClick();
        }}
      >
        {/* Moon body */}
        <div className="w-20 h-20 md:w-28 md:h-28 rounded-full moon-glow relative overflow-hidden"
          style={{
            background: 'radial-gradient(circle at 35% 35%, #f5f3e8, #e8e4d0 40%, #d4cfb8 70%, #c5bfa5)',
          }}
        >
          {/* Craters */}
          <div className="absolute top-[25%] left-[20%] w-3 h-3 rounded-full bg-[#c5bfa5]/40" />
          <div className="absolute top-[45%] left-[55%] w-2 h-2 rounded-full bg-[#c5bfa5]/30" />
          <div className="absolute top-[60%] left-[30%] w-4 h-4 rounded-full bg-[#c5bfa5]/25" />
          <div className="absolute top-[20%] left-[60%] w-1.5 h-1.5 rounded-full bg-[#c5bfa5]/35" />

          {/* Hover hint - very subtle */}
          <div className="absolute inset-0 rounded-full bg-white/0 group-hover:bg-white/5 transition-all duration-700" />
        </div>

        {/* Outer glow ring */}
        <div
          className="absolute -inset-4 rounded-full opacity-30 group-hover:opacity-50 transition-opacity duration-1000"
          style={{
            background: 'radial-gradient(circle, rgba(255, 255, 240, 0.1) 0%, transparent 70%)',
          }}
        />
      </div>
    </motion.div>
  );
}