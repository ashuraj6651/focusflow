'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowDown } from 'lucide-react';
import StarField from '@/components/effects/StarField';
import Moon from '@/components/landing/Moon';
import TypingText from '@/components/landing/TypingText';

interface LandingSectionProps {
  onBegin: () => void;
  onSecretLetter: () => void;
}

export default function LandingSection({ onBegin, onSecretLetter }: LandingSectionProps) {
  const [showArrow, setShowArrow] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowArrow(true), 5000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="relative h-screen w-full flex flex-col items-center justify-center overflow-hidden">
      {/* Stars background */}
      <StarField />

      {/* Aurora effect */}
      <div className="aurora-bg" aria-hidden="true" />

      {/* Moon */}
      <Moon onDoubleClick={onSecretLetter} />

      {/* Main content */}
      <div className="relative z-10 text-center px-6 max-w-2xl mx-auto">
        {/* Decorative line */}
        <motion.div
          initial={{ scaleX: 0, opacity: 0 }}
          animate={{ scaleX: 1, opacity: 1 }}
          transition={{ duration: 1.5, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="w-16 h-px bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent mx-auto mb-8"
        />

        {/* Typing text */}
        <div className="min-h-[80px] md:min-h-[60px] flex items-center justify-center">
          <TypingText
            text="Some stories don't need an audience."
            speed={55}
            delay={1000}
            className="text-lg md:text-2xl text-white/60 font-light tracking-wide"
          />
        </div>

        <div className="min-h-[80px] md:min-h-[60px] flex items-center justify-center mt-2">
          <TypingText
            text="They only need two hearts."
            speed={55}
            delay={3500}
            className="text-lg md:text-2xl text-[#D4AF37]/80 font-light tracking-wide"
          />
        </div>

        {/* Decorative line */}
        <motion.div
          initial={{ scaleX: 0, opacity: 0 }}
          animate={{ scaleX: 1, opacity: 1 }}
          transition={{ duration: 1.5, delay: 6, ease: [0.16, 1, 0.3, 1] }}
          className="w-16 h-px bg-gradient-to-r from-transparent via-[#D4AF37]/50 to-transparent mx-auto mt-8"
        />

        {/* Begin button */}
        <AnimatePresence>
          {showArrow && (
            <motion.button
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              onClick={onBegin}
              className="mt-12 group inline-flex flex-col items-center gap-2 cursor-pointer"
            >
              <span className="text-sm text-white/40 tracking-[0.3em] uppercase group-hover:text-[#D4AF37]/60 transition-colors duration-500">
                Begin
              </span>
              <motion.div
                animate={{ y: [0, 6, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
              >
                <ArrowDown className="w-4 h-4 text-white/30 group-hover:text-[#D4AF37]/50 transition-colors duration-500" />
              </motion.div>
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#09090B] to-transparent z-[5]" />
    </section>
  );
}