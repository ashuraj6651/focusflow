'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import PolaroidCard from '@/components/gallery/PolaroidCard';
import type { Photo } from '@/types';

export default function GallerySection() {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadPhotos() {
      try {
        const res = await fetch('/api/photos');
        if (res.ok) {
          const data = await res.json();
          setPhotos(data);
        }
      } catch {
        // silently fail — gallery shows empty state
      } finally {
        setIsLoading(false);
      }
    }
    loadPhotos();
  }, []);

  const rotations = [-2.5, 1.8, -1.2, 2.8, -2, 1.5, -1.8, 2.2, -0.8, 1];

  return (
    <section className="relative min-h-screen py-24 md:py-32 px-6">
      {/* Section header */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="text-center mb-6"
      >
        <p className="text-[11px] tracking-[0.4em] uppercase text-[#D4AF37]/40 mb-4">
          i.
        </p>
        <h2 className="text-3xl md:text-5xl font-extralight text-white/90 tracking-tight">
          The <span className="gold-text font-light">Beginning</span>
        </h2>
      </motion.div>

      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1, delay: 0.3 }}
        className="text-center text-sm text-white/25 max-w-md mx-auto mb-16 md:mb-24 font-light leading-relaxed"
      >
        Every story starts somewhere. Ours started the way the best ones do — quietly, unexpectedly, and with a feeling that something was different this time.
      </motion.p>

      <motion.div
        initial={{ scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1, delay: 0.2 }}
        className="w-20 h-px bg-gradient-to-r from-transparent via-[#D4AF37]/30 to-transparent mx-auto mb-16 md:mb-24"
      />

      {/* Gallery grid */}
      {isLoading ? (
        <div className="flex justify-center py-20">
          <div className="w-6 h-6 border border-[#D4AF37]/15 border-t-[#D4AF37]/60 rounded-full animate-spin" />
        </div>
      ) : photos.length > 0 ? (
        <div className="max-w-6xl mx-auto">
          {/* Masonry-inspired storytelling layout */}
          <div className="columns-1 sm:columns-2 lg:columns-3 gap-8 md:gap-10 space-y-8 md:space-y-10">
            {photos.map((photo, i) => (
              <div
                key={photo.id}
                className="break-inside-avoid"
                style={{
                  transform: `rotate(${rotations[i % rotations.length]}deg)`,
                  transition: 'transform 0.5s cubic-bezier(0.03, 0.98, 0.52, 0.99)',
                }}
              >
                <PolaroidCard
                  src={photo.src}
                  alt={photo.alt}
                  caption={photo.caption}
                  index={i}
                  rotation={0}
                />
              </div>
            ))}
          </div>
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="text-center py-16"
        >
          <div className="glass rounded-2xl p-12 md:p-16 max-w-sm mx-auto">
            <div className="w-10 h-10 rounded-full glass flex items-center justify-center mx-auto mb-6">
              <svg className="w-4 h-4 text-[#D4AF37]/30" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909M3.75 21h16.5a1.5 1.5 0 001.5-1.5V5.25a1.5 1.5 0 00-1.5-1.5H3.75a1.5 1.5 0 00-1.5 1.5v14.25a1.5 1.5 0 001.5 1.5z" />
              </svg>
            </div>
            <p className="text-white/25 text-sm leading-relaxed font-light">
              Place photos in the <code className="text-[#D4AF37]/30 text-xs bg-white/5 px-1.5 py-0.5 rounded">private-photos/</code> folder
              <br />
              <span className="text-white/15 text-xs">They&apos;ll appear here as polaroid memories.</span>
            </p>
          </div>
        </motion.div>
      )}

      <div className="h-24" />
    </section>
  );
}