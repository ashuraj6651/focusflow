'use client';

import { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { useTilt } from '@/hooks/useTilt';

interface PolaroidCardProps {
  src: string;
  alt: string;
  caption?: string;
  index: number;
  rotation?: number;
}

export default function PolaroidCard({ src, alt, caption, index, rotation = 0 }: PolaroidCardProps) {
  const { ref, handleMouseMove, handleMouseLeave } = useTilt({
    maxTilt: 8,
    perspective: 800,
    scale: 1.03,
    speed: 500,
  });
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 60, rotate: rotation * 0.5 }}
      whileInView={{ opacity: 1, y: 0, rotate: rotation }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{
        duration: 0.8,
        delay: index * 0.12,
        ease: [0.16, 1, 0.3, 1],
      }}
    >
      <div
        ref={ref}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        className="polaroid cursor-pointer will-change-transform"
        style={{
          width: '100%',
          maxWidth: '320px',
          transformStyle: 'preserve-3d',
        }}
      >
        <div className="relative w-full aspect-[4/3] overflow-hidden bg-zinc-800">
          {/* Loading shimmer */}
          {!isLoaded && !hasError && (
            <div className="absolute inset-0 bg-gradient-to-r from-zinc-800 via-zinc-700 to-zinc-800 animate-pulse" />
          )}

          <img
            src={src}
            alt={alt}
            loading="lazy"
            onLoad={() => setIsLoaded(true)}
            onError={() => setHasError(true)}
            className={`object-cover transition-all duration-700 w-full h-full group-hover:scale-110 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
            draggable={false}
          />

          {/* Hover overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent opacity-0 hover:opacity-100 transition-opacity duration-500" />
        </div>
        {caption && (
          <p className="mt-3 text-center text-xs text-zinc-600 handwritten leading-relaxed">
            {caption}
          </p>
        )}
      </div>
    </motion.div>
  );
}