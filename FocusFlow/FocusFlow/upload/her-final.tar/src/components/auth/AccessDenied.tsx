'use client';

import { motion } from 'framer-motion';
import { Shield, Lock } from 'lucide-react';

export default function AccessDenied() {
  return (
    <div className="min-h-screen flex items-center justify-center px-6 bg-[#09090B]">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center max-w-md"
      >
        {/* Icon */}
        <motion.div
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="w-20 h-20 rounded-full glass flex items-center justify-center mx-auto mb-8"
        >
          <Shield className="w-8 h-8 text-red-400/60" />
        </motion.div>

        {/* 403 */}
        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-6xl md:text-7xl font-extralight text-white/10 tracking-tighter mb-4"
        >
          403
        </motion.h1>

        {/* Title */}
        <motion.h2
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-xl md:text-2xl font-light text-white/80 mb-4 tracking-tight"
        >
          Access Denied
        </motion.h2>

        {/* Description */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="text-sm text-white/30 leading-relaxed mb-8"
        >
          This is a private space, reserved for someone special.
          <br />
          If you believe this is an error, well... it&apos;s not.
        </motion.p>

        {/* Lock icon */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="flex items-center justify-center gap-2 text-white/15"
        >
          <Lock className="w-3 h-3" />
          <span className="text-[10px] tracking-[0.3em] uppercase">Protected</span>
        </motion.div>
      </motion.div>
    </div>
  );
}