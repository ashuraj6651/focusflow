'use client';

import { motion } from 'framer-motion';
import { signIn } from 'next-auth/react';
import { Loader2, LogIn } from 'lucide-react';
import { useState } from 'react';

export default function AuthGate() {
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    setIsLoading(true);
    try {
      await signIn('google', { callbackUrl: '/' });
    } catch {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6 bg-[#09090B] relative overflow-hidden">
      {/* Subtle aurora */}
      <div className="aurora-bg opacity-30" aria-hidden="true" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
        className="text-center max-w-sm relative z-10"
      >
        {/* Decorative */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 1.5, delay: 0.3 }}
          className="w-12 h-px bg-gradient-to-r from-transparent via-[#D4AF37]/30 to-transparent mx-auto mb-10"
        />

        {/* Lock icon */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="w-16 h-16 rounded-full glass flex items-center justify-center mx-auto mb-8 animate-pulse-glow"
        >
          <LogIn className="w-6 h-6 text-[#D4AF37]/60" />
        </motion.div>

        {/* Title */}
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="text-2xl md:text-3xl font-extralight text-white/90 tracking-tight mb-3"
        >
          A Private Space
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7, duration: 0.8 }}
          className="text-sm text-white/30 leading-relaxed mb-10"
        >
          This experience was created for someone specific.
          <br />
          If that&apos;s you, sign in to continue.
        </motion.p>

        {/* Sign in button */}
        <motion.button
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.8 }}
          onClick={handleLogin}
          disabled={isLoading}
          className="group relative w-full glass rounded-xl px-6 py-4 flex items-center justify-center gap-3 hover:glass-strong transition-all duration-500 disabled:opacity-50 cursor-pointer"
        >
          {/* Google icon */}
          <svg className="w-5 h-5" viewBox="0 0 24 24" aria-hidden="true">
            <path
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
              fill="#4285F4"
            />
            <path
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              fill="#34A853"
            />
            <path
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              fill="#FBBC05"
            />
            <path
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              fill="#EA4335"
            />
          </svg>

          <span className="text-sm text-white/70 group-hover:text-white transition-colors duration-300">
            {isLoading ? 'Signing in...' : 'Continue with Google'}
          </span>

          {isLoading && (
            <Loader2 className="w-4 h-4 text-[#D4AF37] animate-spin" />
          )}
        </motion.button>

        {/* Footer note */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.8 }}
          className="mt-8 text-[10px] text-white/15 tracking-wider"
        >
          Only for the intended hearts
        </motion.p>
      </motion.div>
    </div>
  );
}